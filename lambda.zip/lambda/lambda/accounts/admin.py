from django.contrib import admin

from django.contrib.auth import get_user_model
from django.contrib.auth.admin import UserAdmin

from .models import CustomUser
# Register your models here.

@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
  
    model = CustomUser
    list_display = ['username','last_name','first_name','position','phone','is_staff','is_active',]
    list_editable =['position','phone',]
    list_display_links = ['username','last_name',]

 


