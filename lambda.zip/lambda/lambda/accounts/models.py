
from business.models import BaseModel
from django.conf import settings
from django.contrib.auth.models import AbstractUser
from django.db import models
from django.db.models.signals import post_save
from django.dispatch import receiver
from django.shortcuts import redirect, reverse
from rest_framework.authtoken.models import Token
class CustomUser(AbstractUser,BaseModel):
    position =models.CharField(max_length=200,null=True, blank=True)
    phone = models.CharField(max_length=15,help_text='optional',unique=True,null=True, blank=True)
    
    USERNAME_FIELD = 'username'
    # REQUIRED_FIELDS = ['first_name', 'last_name']

    def __str__(self):
        return f"{self.first_name} {self.last_name}"
        
    @property
    def get_full_name(self):
        if self.first_name or self.last_name:
            return self.first_name + " " + self.last_name
        if self.username:
            return self.username
        else:
            return 'Not Loged in'





@receiver(post_save, sender=settings.AUTH_USER_MODEL)
def create_auth_token(sender, instance=None, created=False, **kwargs):
    if created:
        Token.objects.create(user=instance)
        

