from django.urls import path,include
from  . import views
urlpatterns = [
     # API AUTH EDPOINTS
    path('api/auth/', include('rest_framework.urls')),#rest login on right top

    path('api/auth/', include('djoser.urls')),
    path('api/auth/', include('djoser.urls.authtoken')),
    path('api/auth/user_status/<int:pk>/', views.set_user_status,),

    path('', views.sayHi)
]