from django.shortcuts import get_object_or_404, render
from rest_framework import mixins, permissions, status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.response import Response
from .models import CustomUser
from .serializers import CustomUserSerializer
# Create your views here.


@api_view(['PATCH', 'PUT','GET',])
@permission_classes([permissions.IsAdminUser])
def set_user_status(request,pk):
    """
    PATCH request sets user password to default ( changeme@123 ) 

    PUT request disables or enables the user.

    GET request checks if user is using default password.
    
    """
    user_pk = request.query_params.get('pk')
    user = get_object_or_404(CustomUser, pk=pk)
    serializer = CustomUserSerializer(user,many=False)

    print('persers',user_pk)

    if request.method == 'PATCH':
        user.set_password('changeme@123')
        user.save()

        return Response({'user': user.get_full_name,'password set to default':True}, status=status.HTTP_200_OK)

    if request.method == 'PUT':   
        # disable or enable user
        user.is_active =True if not user.is_active else False  
        user.save()

        return Response({'user': user.get_full_name,'active account':user.is_active}, status=status.HTTP_200_OK)
    
    if request.method == 'GET':
        
        default_password = user.check_password('changeme@123')
        return Response(serializer.data,)



@api_view(['GET',])
def sayHi(request):
    
    return Response(data={'user': str(request.user)})
