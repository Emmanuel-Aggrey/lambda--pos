from django.contrib import admin
from .models import Business,Supplier
from stores.models import Product
# Register your models here.


# admin.site.register(Business)


# class CustomUserInline(admin.TabularInline):
#     model = CustomUser
#     # add_form = CustomUserCreationForm
#     # form = CustomUserChangeForm
#     fields = ['username','first_name','last_name','position','phone','email',]

@admin.register(Business)
class BusinessAdmin(admin.ModelAdmin):
    list_display = ['name', 'contact','location','head','available','date_created','get_users_total']
    list_filter = ['name','available']
    search_fields = ('contact','name','location','head',)
    list_editable = ['available',]
    list_display_links = ['name','contact',]

# admin.site.register(Business, BusinessAdmin)



class ProductInline(admin.TabularInline):
    model = Product
  
    fields = ['name','quantity','generic','unit','supplier','has_expire_date','expire_date',]



class SupplierAdmin(admin.ModelAdmin):
    list_display = ['name', 'contact','location','available','date_created','get_total_purchased']
    list_filter = ['name','available']
    inlines = [ProductInline]
    search_fields = ('contact','name','location')
    list_editable = ['available',]
    list_display_links = ['name','contact',]

admin.site.register(Supplier, SupplierAdmin)


