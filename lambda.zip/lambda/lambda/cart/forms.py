from django import forms
from stock.models import  Location

PRODUCT_QUANTITY_CHOICES = [(i, str(i)) for i in range(1, 101)]


class CartAddProductForm(forms.Form):
    quantity = forms.TypedChoiceField(choices=PRODUCT_QUANTITY_CHOICES, coerce=int)
    update = forms.BooleanField(required=False, initial=False, widget=forms.HiddenInput)
    location = forms.ModelChoiceField(queryset=Location.objects.all(),empty_label='Location',help_text='select location',required=False)
    serial_number =forms.CharField(widget = forms.TextInput(attrs={'readonly':'readonly'}))