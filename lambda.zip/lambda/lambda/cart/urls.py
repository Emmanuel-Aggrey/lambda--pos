from django.urls import  path
from . import views

app_name = 'cart'

urlpatterns = [
    path('add/<int:product_id>/', views.cart_add, name='cart_add'),
    path('remove/<int:product_id>/',views.cart_remove,name='cart_remove'),
    path('cart_detail/', views.cart_detail, name='cart_detail'),
    path('get_cart_size/',views.get_cart_size,name='get_cart_size'),


    # # new_cart
    path('add/new/<int:product_id>/', views.issue_cart_add, name='issue_cart_add'),
    path('issue_remove/<int:product_id>/',views.issue_cart_remove,name='issue_cart_remove'),
    path('issue_cart_detail/', views.issue_cart_detail, name='issue_cart_detail'),

]

