from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST
from stock.models import Product
from .cart import Cart
from .forms import CartAddProductForm
from  django.http import  HttpResponse
from django.contrib.auth.decorators import  login_required
from django.contrib import messages
from django.http import JsonResponse

# cart for issueing out
@require_POST
@login_required
def cart_add(request,product_id):
    cart = Cart(request)  # create a new cart object passing it the request object 
    product = get_object_or_404(Product, id=product_id) 
    form = CartAddProductForm(request.POST)
    
    if form.is_valid():
        cd = form.cleaned_data
        # location = form.cleaned_data['location']
        # print('cd is', cd,'location is ',location)
        location= request.POST.get('location')
        serial_number= request.POST.get('serial_number',None)

        print('form valid ',"serial_number",serial_number,'location',location)

        cart.add(product=product, quantity=cd['quantity'], update_quantity=cd['update'],location=location,serial_number=serial_number)
        # messages.success(request,'data saved')
    if form.errors:
        print(form.errors)
        

    return redirect('cart:cart_detail')


@login_required
def cart_remove(request, product_id):
    cart = Cart(request)
    product = get_object_or_404(Product, id=product_id)
    cart.remove(product)
    return redirect('cart:cart_detail')

@login_required
def cart_detail(request):
    cart = Cart(request)
    for item in cart:
        # pass
        # item['update_quantity_form'] = CartAddProductForm(initial={'quantity': item['quantity'], 'update': True,})

            item['update_quantity_form'] = CartAddProductForm(initial={'quantity': item['quantity'], 'update': True,'location':item['location'],'serial_number':item['serial_number']})

    return render(request,'stock/stock_app/cart_detail.html', {'cart':cart})



def get_cart_size(request):
    return JsonResponse(len(Cart(request)),safe=False)


# cart for issueing new item


# cart for issueing out
@login_required
@require_POST
def issue_cart_add(request,product_id):
    cart_2 = Cart(request)  # create a new cart object passing it the request object 
    product = get_object_or_404(Product, id=product_id) 
    form = CartAddProductForm(request.POST)
    if form.is_valid():
        cd = form.cleaned_data
        cart_2.add(product=product, quantity=cd['quantity'], update_quantity=cd['update'])
    return redirect('cart:issue_cart_detail')

@login_required
def issue_cart_remove(request, product_id):
    cart_2 = Cart(request)
    product = get_object_or_404(Product, id=product_id)
    cart_2.remove(product)
    return redirect('cart:issue_cart_detail')

@login_required
def issue_cart_detail(request):
    cart_2 = Cart(request)
    for item in cart_2:
        item['update_quantity_form'] = CartAddProductForm(initial={'quantity': item['quantity'], 'update': True})
    return render(request,'new_order/cart_detail.html', {'cart_2': cart_2})