# from auditlog.registry import auditlog
from business.models import BaseModel, Supplier
from django.db import models
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
from django.shortcuts import reverse
from django.utils import timezone
from datetime import timedelta
from dateutil import relativedelta


# Create your models here.
class Generic(BaseModel):
    name = models.CharField(
        help_text='eg paracetamol', max_length=100, unique=True)

    def __str__(self):
        return self.name

    @property
    def get_total_category(self):
        return self.generics.count()


# auditlog.register(Generic)


class Category(BaseModel):
    name = models.CharField(
        help_text='eg syrup,tablet,cream', max_length=100, unique=True)
    generic = models.ForeignKey(Generic, on_delete=models.CASCADE, blank=True, null=True,
                                help_text='Paracetamol > syrup paracetamol > tablet', related_name='generics')

    def __str__(self):
        return f'{self.name}: {self.generic}'

    @property
    def get_total_products(self):
        return self.categories.count()

    class Meta:
        verbose_name = 'Category'
        verbose_name_plural = 'Categories'

    # def get_absolute_url(self):
    #     return reverse('neworder:issue_in', args=[self.id, self.name])


# auditlog.register(Category)


class Unit(BaseModel):
    unit = models.CharField(max_length=200, help_text='ml, mg, pcs')

    def __str__(self):
        return '{}'.format(self.unit)

    @property
    def get_total_products_by_unit(self):
        return self.units.count()

    class Meta:
        ordering = ('-date_updated',)

# auditlog.register(Category)


class Product(BaseModel):
    name = models.CharField(max_length=100, db_index=True)
    quantity = models.PositiveIntegerField()
    description = models.TextField(blank=True, null=True)
    category = models.ForeignKey(
        Category, on_delete=models.CASCADE, related_name='categories', blank=True, null=True)
    unit = models.ForeignKey(
        Unit, on_delete=models.CASCADE, blank=True, null=True, related_name='units')
    supplier = models.ForeignKey(
        Supplier, on_delete=models.CASCADE, blank=True, null=True, related_name='suppliers')
    receaved_date = models.DateField(
        blank=True, null=True, default=timezone.now)
    stock_level = models.PositiveIntegerField(
        default=10, blank=True, null=True)
    original_stock = models.PositiveIntegerField(
        default=0, null=True, blank=True, editable=False)
    shelf_number = models.CharField(max_length=20, blank=True, null=True)
    has_expire_date = models.BooleanField(default=False)
    months_to_expire = models.PositiveSmallIntegerField(default=0)
    expire_date = models.DateField(blank=True, null=True)

    def get_absolute_url(self):
        return reverse('issue_out', args=[self.id, self.name])

    def __str__(self):
        # return f'{self.name} {self.category.name}'
        return self.name

    # def get_queryset(self, pks):
    #     return Product.objects.filter(pk__in=pks)

    def has_expired(self):

        if self.has_expire_date and self.expire_date:
            #
            difference = relativedelta.relativedelta(
                self.expire_date, timezone.now().date())
            print(difference)

            if timezone.now().date() >= self.expire_date or self.months_to_expire >= difference.months:
                return True
            else:
                return False
        else:
            return 'No Expire Date'

    def difference_btn_two_dates(date1, date2, *args):
        difference = relativedelta.relativedelta(date1, date2)
        return difference


@receiver(pre_save, sender=Product)
def update_original_stock(sender, instance, *args, **kwargs):
    if instance.quantity:

        instance.original_stock = int(
            instance.quantity) + int(instance.original_stock)
        # print('instance', instance.original_stock)
        # instance.save()


# auditlog.register(Product)

class Item(models.Model):
    name = models.ForeignKey(
        Product, on_delete=models.CASCADE, related_name='items')
    serial_number = models.CharField(max_length=200, blank=True, null=True)

    def get_absolute_url(self):
        return reverse('neworder:issue_in', args=[self.id, self.name.name])


# auditlog.register(Item)
